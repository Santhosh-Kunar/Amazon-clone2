import React from 'react'
import Home from './Home'

const Navbar = () => {
  return (
      <div>
          <Home/>
    </div>
  )
}

export default Navbar